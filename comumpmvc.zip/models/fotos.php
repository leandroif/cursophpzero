<?php
class Fotos extends model {
        
}