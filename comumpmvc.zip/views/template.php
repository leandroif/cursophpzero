<html>
    <head>
        <meta charset="UTF-8">
        <title>Galeria de Fotos</title>
    </head>
    <body>
        <?php
        $this->loadViewInTemplate($viewName, $viewData);
        ?>
    </body>
</html>
